package com.bitchordlite.app.source
import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.bitchordlite.app.model.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LocalMusicSource(private val context: Context) {
    suspend fun getSongs(): List<Song> = withContext(Dispatchers.IO) {
        val out = mutableListOf<Song>()
        val songsUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID
        )
        context.contentResolver.query(
            songsUri, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val title = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val album = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val dur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            while (c.moveToNext()) {
                val songId = c.getLong(id)
                val art = ContentUris.withAppendedId(
                    MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI, c.getLong(albumId)
                ).toString()
                out += Song(songId, c.getString(title) ?: "Unknown",
                    c.getString(artist) ?: "Unknown artist",
                    c.getString(album) ?: "Unknown album",
                    ContentUris.withAppendedId(songsUri, songId).toString(),
                    art, c.getLong(dur))
            }
        }
        out
    }
}
