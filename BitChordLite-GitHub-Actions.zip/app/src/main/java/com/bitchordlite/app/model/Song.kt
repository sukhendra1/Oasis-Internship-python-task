package com.bitchordlite.app.model
data class Song(
    val id: Long, val title: String, val artist: String, val album: String,
    val uri: String, val albumArtUri: String? = null, val durationMs: Long = 0L
)
