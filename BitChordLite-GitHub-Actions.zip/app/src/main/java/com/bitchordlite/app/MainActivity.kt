package com.bitchordlite.app

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.bitchordlite.app.model.Song
import com.bitchordlite.app.player.PlaybackService
import com.bitchordlite.app.source.LocalMusicSource
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

private val Bg = Color(0xFF0B0B0F)
private val Card = Color(0xFF18181E)
private val Accent = Color(0xFF1ED760)

class MainVM(private val app: android.app.Application): ViewModel() {
    private val source = LocalMusicSource(app)
    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs = _songs.asStateFlow()
    val query = MutableStateFlow("")
    val favorites = MutableStateFlow<Set<Long>>(emptySet())
    fun load() { viewModelScope.launch { _songs.value = source.getSongs() } }
    fun toggleFavorite(id: Long) {
        favorites.value = favorites.value.toMutableSet().also { if (!it.add(id)) it.remove(id) }
    }
    fun filtered(): List<Song> = _songs.value.filter {
        val q = query.value
        q.isBlank() || it.title.contains(q,true) || it.artist.contains(q,true) || it.album.contains(q,true)
    }
}

class MainActivity : ComponentActivity() {
    private val vm by viewModels<MainVM>()
    private var controller: MediaController? = null
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) vm.load()
    }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        MediaController.Builder(this, token).buildAsync().addListener(
            { controller = MediaController.Builder(this, token).buildAsync().get() },
            { it.run() }
        )
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED)
            permission.launch(Manifest.permission.READ_MEDIA_AUDIO)
        else vm.load()
        setContent { MaterialTheme(colorScheme = darkColorScheme(background=Bg, surface=Card, primary=Accent)) {
            App(vm) { song -> play(song) }
        }}
    }
    private fun play(song: Song) {
        val c = controller ?: return
        val item = MediaItem.Builder().setUri(song.uri).setMediaMetadata(
            MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist)
                .setAlbumTitle(song.album).setArtworkUri(song.albumArtUri?.let(android.net.Uri::parse)).build()
        ).build()
        c.setMediaItem(item); c.prepare(); c.play()
    }
}

@Composable fun App(vm: MainVM, play: (Song)->Unit) {
    val songs by vm.songs.collectAsState()
    val fav by vm.favorites.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Song?>(null) }
    Scaffold(containerColor=Bg, bottomBar={
        NavigationBar(containerColor=Card) {
            listOf(Icons.Default.Home to "Home", Icons.Default.Search to "Search", Icons.Default.LibraryMusic to "Library").forEachIndexed { i, p ->
                NavigationBarItem(tab==i,{tab=i},{Icon(p.first,null)},label={Text(p.second)})
            }
        }
    }) { pad ->
        when(tab) {
            0 -> Home(pad,songs,fav,play,{vm.toggleFavorite(it)})
            1 -> Search(pad,vm,songs,fav,play,{vm.toggleFavorite(it)})
            else -> Library(pad,songs,fav,play)
        }
        selected?.let { /* reserved for full player screen */ }
    }
}

@Composable fun Home(p:PaddingValues,songs:List<Song>,fav:Set<Long>,play:(Song)->Unit,toggle:(Long)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(p).padding(horizontal=20.dp),contentPadding=PaddingValues(vertical=28.dp)) {
        item { Text("Good evening",28.sp,FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text("Your music",21.sp,FontWeight.Bold); Spacer(Modifier.height(14.dp)) }
        items(songs,key={it.id}) { SongRow(it,fav.contains(it.id),play,toggle) }
    }
}
@Composable fun Search(p:PaddingValues,vm:MainVM,songs:List<Song>,fav:Set<Long>,play:(Song)->Unit,toggle:(Long)->Unit) {
    val q by vm.query.collectAsState()
    Column(Modifier.fillMaxSize().padding(p).padding(20.dp)) {
        Text("Search",28.sp,FontWeight.Bold); Spacer(Modifier.height(14.dp))
        OutlinedTextField(q,{vm.query.value=it},Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Songs, artists, albums")},leadingIcon={Icon(Icons.Default.Search,null)})
        Spacer(Modifier.height(12.dp))
        LazyColumn { items(songs.filter{q.isBlank()||it.title.contains(q,true)||it.artist.contains(q,true)||it.album.contains(q,true)},key={it.id}) { SongRow(it,fav.contains(it.id),play,toggle) } }
    }
}
@Composable fun Library(p:PaddingValues,songs:List<Song>,fav:Set<Long>,play:(Song)->Unit) {
    val favorites=songs.filter{fav.contains(it.id)}
    Column(Modifier.fillMaxSize().padding(p).padding(20.dp)) {
        Text("Your Library",28.sp,FontWeight.Bold); Spacer(Modifier.height(16.dp))
        Text("Favorites (${favorites.size})",20.sp,FontWeight.Bold); Spacer(Modifier.height(8.dp))
        LazyColumn { items(favorites,key={it.id}) { SongRow(it,true,play,{}) } }
    }
}
@Composable fun SongRow(song:Song,isFav:Boolean,play:(Song)->Unit,toggle:(Long)->Unit) {
    Row(Modifier.fillMaxWidth().clickable{play(song)}.padding(vertical=9.dp),verticalAlignment=Alignment.CenterVertically) {
        AsyncImage(song.albumArtUri,null,Modifier.size(54.dp).clip(RoundedCornerShape(8.dp)).background(Card),contentScale=ContentScale.Crop)
        Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) {
            Text(song.title,maxLines=1,fontWeight=FontWeight.SemiBold); Text("${song.artist} • ${song.album}",maxLines=1,color=Color.Gray,fontSize=13.sp)
        }
        IconButton({toggle(song.id)}) { Icon(if(isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(isFav) Accent else Color.Gray) }
    }
}
