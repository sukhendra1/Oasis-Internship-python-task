package com.bitchordlite.app.player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private lateinit var player: ExoPlayer
    private var session: MediaSession? = null
    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this).build().apply { setHandleAudioBecomingNoisy(true) }
        session = MediaSession.Builder(this, player).setCallback(MediaSession.Callback { _, _ -> true }).build()
    }
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session
    override fun onDestroy() {
        session?.release(); player.release(); super.onDestroy()
    }
}
